# --------------------- WEBHOOK URL ---------------------
WEBHOOK = "https://discord.com/api/webhooks/1252276968435486740/LgruubTxZahXp8a2B5KAvOXRHpF6rrLxrfFu2Zxj4AzAn27vPjlT0nPScAT-W0-vUl4X"

# --------------------- SHOPIFY URL ---------------------
# Ensure the URL is one that contains products.json (e.g. https://www.hanon-shop.com/collections/whats-new/products.json)
URL = "https://sneakersclinic.com/products.json"

# --------------------- FREE PROXY ---------------------
# A single or multiple locations can be added in the array (e.g. ["GB"] or ["GB", "US"])
ENABLE_FREE_PROXY = False
FREE_PROXY_LOCATION = ["GB"]

# --------------------- DELAY ---------------------
# Delay between site requests
DELAY = 300

# --------------------- OPTIONAL PROXY ---------------------
# Proxies must follow this format: "<proxy>:<port>" OR "<proxy_username>:<proxy_password>@<proxy_domain>:<port>")
# If you want to use multiple proxies, please create an array
# E.G. PROXY = ["proxy1:proxy1port", "proxy2:proxy2port"]
PROXY = []

# --------------------- OPTIONAL KEYWORDS ---------------------
# E.G. KEYWORDS = ["box","logo"]
KEYWORDS = []

# --------------------- DISCORD BOT FEATURES ---------------------
USERNAME = "sneakersclinic-sg"
AVATAR_URL = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR61XiBMenM4lItHJrD-DepCLLwLcOZKNku_A&s"
COLOUR = 16777215