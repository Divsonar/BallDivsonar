# --------------------- WEBHOOK URL ---------------------
WEBHOOK = []

# --------------------- SHOPIFY URL ---------------------
# Ensure the URL is one that contains products.json (e.g. https://www.hanon-shop.com/collections/whats-new/products.json)
URL = [
    {
    "url": "https://www.actioncity.com.sg/collections/be-rbrick/products.json",
    "webhook": "https://discordapp.com/api/webhooks/1255180097464434728/KBYQkflB30-WK919a9xSFmivG35YBu3sv946mTOJssrKEYfQ1R9Ni2t159scIhl406Kk"
    },
    {
    "url": "https://sneakersclinic.com/products.json",
    "webhook": "https://discord.com/api/webhooks/1252276968435486740/LgruubTxZahXp8a2B5KAvOXRHpF6rrLxrfFu2Zxj4AzAn27vPjlT0nPScAT-W0-vUl4X"
    },
    {
    "url": "https://limitededt.com/products.json",
    "webhook": "https://discord.com/api/webhooks/1252284895431233626/DMkD9zA1HsPODzwmC2y_jCyiMEmppV_RJhcfNrkG631alYXjgufiNKzr7lI2M9PXNQR-"
    },
    {
    "url": "https://shop-sg.doverstreetmarket.com/products.json",
    "webhook": "https://discord.com/api/webhooks/1252271633381462037/CvYiUWS19gatiOYfTS2dC_Y6-Xq_L5Ni9A3DgmIteQtYpg2fQfSA_xy0HDfRb4f-HJCi"
    },
    {
    "url": "https://mct.tokyo/en/collections/bearbrick/products.json",
    "webhook": "https://discordapp.com/api/webhooks/1255558053915263016/-i0oqDqpa3Cv2s35qL0_pcii8vp1ZvH_613CNN4sVQ3qEwbY9qq_D2jgc8fodZMrU23t"
    },
    {
    "url": "https://ddtstore.com/collections/kaws/products.json",
    "webhook": "https://discordapp.com/api/webhooks/1255560832134156398/xz_YWz5JFeV1_LsuBF98oCqAj_idbWENlZDzU8bFI4hswL9lXZOG7FLR8DYt2oCeB9aU"
    },
    {
    "url": "https://www.culturekings.com.au/collections/nike/products.json",
    "webhook": "https://discordapp.com/api/webhooks/1255568439758815266/io-jA9y6d_m8rgRDBxNYnWjTk4jWXzJNS31SDNznYXGd_zkRG-t_gNKuAVqd2l3kqc7r"
    },
    {
    "url": "https://www.culturekings.com.au/collections/jordan/products.json",
    "webhook": "https://discordapp.com/api/webhooks/1255568439758815266/io-jA9y6d_m8rgRDBxNYnWjTk4jWXzJNS31SDNznYXGd_zkRG-t_gNKuAVqd2l3kqc7r"
    },
    {
    "url": "https://www.culturekings.com.au/collections/stussy/products.json",
    "webhook": "https://discordapp.com/api/webhooks/1255568439758815266/io-jA9y6d_m8rgRDBxNYnWjTk4jWXzJNS31SDNznYXGd_zkRG-t_gNKuAVqd2l3kqc7r"
    },
    {
    "url": "https://kith.com/collections/nike/products.json",
    "webhook": "https://discordapp.com/api/webhooks/1255568690821333105/Vqv9ZcqtBSLr0AymvFvOWMMC4t1PYwTO-gCgALszzixF4XeN5YiTniZBG5pB9ERb7FTo"
    },
    {
    "url": "https://kith.com/collections/jordan/products.json",
    "webhook": "https://discordapp.com/api/webhooks/1255568690821333105/Vqv9ZcqtBSLr0AymvFvOWMMC4t1PYwTO-gCgALszzixF4XeN5YiTniZBG5pB9ERb7FTo"
    },
    {
    "url": "https://kith.com/collections/kith-monday-program/products.json",
    "webhook": "https://discordapp.com/api/webhooks/1255568690821333105/Vqv9ZcqtBSLr0AymvFvOWMMC4t1PYwTO-gCgALszzixF4XeN5YiTniZBG5pB9ERb7FTo"
    },
    {
    "url": "https://cncpts.com/collections/jordan/products.json",
    "webhook": "https://discordapp.com/api/webhooks/1255569350455332985/ZFMXONhCQEucGDvanU3yW70BTmCnhNgPNl-eyTu5mb5JC4MmmAqUv9vbcQzWssNsMAAX"
    },
    {
    "url": "https://www.preduce.com/products.json",
    "webhook": "https://discordapp.com/api/webhooks/1255596539468845212/2uEGGIpyiUE7OzGhO1X8asEwcnxGtB1Q1kcLseihYM4v_ViUzk-5NTkmDpw9FqwaMRaz"
    },
    {
    "url": "https://hundredpercent.com.my/collections/nike/products.json",
    "webhook": "https://discordapp.com/api/webhooks/1255607114840277052/NjauRUaSSL2_fKodTN-6hBGckD20C7Servn0x-avTMnl4ip7F3A92uQ-pD5aP-kEjbi7"
    },
    {
    "url": "https://atmos-bangkok.com/collections/nike/products.json",
    "webhook": "https://discordapp.com/api/webhooks/1255609387192422511/dhXy6vec_kh6DCk1m3E-9kkopWNIY6FwtEqu61K9DRXSjU7sPGndbcBDu7azv6PtKCkk"
    },
    {
    "url": "https://atmos-bangkok.com/collections/nike-jordan/products.json",
    "webhook": "https://discordapp.com/api/webhooks/1255609387192422511/dhXy6vec_kh6DCk1m3E-9kkopWNIY6FwtEqu61K9DRXSjU7sPGndbcBDu7azv6PtKCkk"
    },
    {
    "url": "https://juicestore.com/collections/nike/products.json",
    "webhook": "https://discordapp.com/api/webhooks/1255610853999247440/j72rPZLRdjXQZ2idM0zmcLHj_8EToRTDCeo6PuItoxwRW_xVB0_FJxvHxiItQwPviI3_"
    },
    # {
    # "url": "",
    # "webhook": ""
    # },
    # {
    # "url": "",
    # "webhook": ""
    # },
    # {
    # "url": "",
    # "webhook": ""
    # },
    # {
    # "url": "",
    # "webhook": ""
    # },
]

# --------------------- FREE PROXY ---------------------
# A single or multiple locations can be added in the array (e.g. ["GB"] or ["GB", "US"])
ENABLE_FREE_PROXY = False
FREE_PROXY_LOCATION = ["GB"]

# --------------------- DELAY ---------------------
# Delay between site requests
DELAY = 120

# --------------------- OPTIONAL PROXY ---------------------
# Proxies must follow this format: "<proxy>:<port>" OR "<proxy_username>:<proxy_password>@<proxy_domain>:<port>")
# If you want to use multiple proxies, please create an array
# E.G. PROXY = ["proxy1:proxy1port", "proxy2:proxy2port"]
PROXY = []

# --------------------- OPTIONAL KEYWORDS ---------------------
# E.G. KEYWORDS = ["box","logo"]
# KEYWORDS = []
KEYWORDS = ['nike', 'jordan', 'yeezy', 'bearbrick', 'be@rbrick', 'supreme', 'kobe', 'kith', 'stussy', 'kaws', 'medicom']

# --------------------- DISCORD BOT FEATURES ---------------------
USERNAME = "HD Monitors"
AVATAR_URL = "https://res.cloudinary.com/dmubfrefi/image/private/s--X0LLoOBX--/c_crop,h_2728,w_4090,x_334,y_0/f_auto/q_auto/v1/dee-about-cms-prod-medias/cf68f541-fc92-4373-91cb-086ae0fe2f88/002-nike-logos-swoosh-white.jpg?_a=BAACwmBs"
COLOUR = 1376000