# --------------------- WEBHOOK URL ---------------------
WEBHOOK = "https://discord.com/api/webhooks/1252271633381462037/CvYiUWS19gatiOYfTS2dC_Y6-Xq_L5Ni9A3DgmIteQtYpg2fQfSA_xy0HDfRb4f-HJCi"

# --------------------- SHOPIFY URL ---------------------
# Ensure the URL is one that contains products.json (e.g. https://www.hanon-shop.com/collections/whats-new/products.json)
URL = "https://shop-sg.doverstreetmarket.com/products.json"

# --------------------- FREE PROXY ---------------------
# A single or multiple locations can be added in the array (e.g. ["GB"] or ["GB", "US"])
ENABLE_FREE_PROXY = False
FREE_PROXY_LOCATION = ["GB"]

# --------------------- DELAY ---------------------
# Delay between site requests
DELAY = 300

# --------------------- OPTIONAL PROXY ---------------------
# Proxies must follow this format: "<proxy>:<port>" OR "<proxy_username>:<proxy_password>@<proxy_domain>:<port>")
# If you want to use multiple proxies, please create an array
# E.G. PROXY = ["proxy1:proxy1port", "proxy2:proxy2port"]
PROXY = []

# --------------------- OPTIONAL KEYWORDS ---------------------
# E.G. KEYWORDS = ["box","logo"]
KEYWORDS = []

# --------------------- DISCORD BOT FEATURES ---------------------
USERNAME = "dsm-sg"
AVATAR_URL = "https://media.licdn.com/dms/image/C560BAQFldPqxrVISeg/company-logo_200_200/0/1631399306279/dover_street_market_singapore_logo?e=2147483647&v=beta&t=6NZwjEPFantDWhgd-iv4ugL_QW3x4MYN_HDdOHJVEog"
COLOUR = 16777215