# --------------------- WEBHOOK URL ---------------------
WEBHOOK = "https://discord.com/api/webhooks/1252284895431233626/DMkD9zA1HsPODzwmC2y_jCyiMEmppV_RJhcfNrkG631alYXjgufiNKzr7lI2M9PXNQR-"

# --------------------- SHOPIFY URL ---------------------
# Ensure the URL is one that contains products.json (e.g. https://www.hanon-shop.com/collections/whats-new/products.json)
URL = "https://limitededt.com/products.json"

# --------------------- FREE PROXY ---------------------
# A single or multiple locations can be added in the array (e.g. ["GB"] or ["GB", "US"])
ENABLE_FREE_PROXY = False
FREE_PROXY_LOCATION = ["GB"]

# --------------------- DELAY ---------------------
# Delay between site requests
DELAY = 300

# --------------------- OPTIONAL PROXY ---------------------
# Proxies must follow this format: "<proxy>:<port>" OR "<proxy_username>:<proxy_password>@<proxy_domain>:<port>")
# If you want to use multiple proxies, please create an array
# E.G. PROXY = ["proxy1:proxy1port", "proxy2:proxy2port"]
PROXY = []

# --------------------- OPTIONAL KEYWORDS ---------------------
# E.G. KEYWORDS = ["box","logo"]
KEYWORDS = []

# --------------------- DISCORD BOT FEATURES ---------------------
USERNAME = "limitededt-sg"
AVATAR_URL = "https://cdn.shopify.com/s/files/1/0099/5232/9785/files/SOCIAL_IMAGE_2c19b5ab-ed39-4b0f-b5b2-a7ab13a88e17.jpg?v=1608441660"
COLOUR = 16777215